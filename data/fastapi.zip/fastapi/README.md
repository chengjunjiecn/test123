# OCR服务API

这是一个基于FastAPI的OCR服务，支持文件上传和OCR文本识别功能。

## 功能说明

1. 文件上传接口：接收HTTP上传的文件，保存到data目录并返回唯一ID
2. OCR识别接口：根据文件ID对图片进行OCR识别并返回文本结果
3. 测试程序：验证HTTP文件上传功能

## API接口

### 1. 文件上传
```
POST /upload/
```
上传文件并返回文件ID

### 2. OCR识别
```
GET /ocr/{file_id}
```
根据文件ID进行OCR识别并返回文本

## 使用方法

1. 安装依赖：
   ```
   pip install -r requirements.txt
   ```

2. 运行服务器：
   ```
   python run_server.py
   ```

3. 使用测试程序：
   ```
   python test_upload.py
   ```

## 注意事项

1. 需要安装Tesseract OCR引擎才能使用OCR功能
2. 默认监听端口为8000
3. 上传的文件保存在data目录下