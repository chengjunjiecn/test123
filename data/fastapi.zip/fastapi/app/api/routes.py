import os
import uuid
from fastapi import APIRouter, UploadFile, File, HTTPException
from pydantic import BaseModel
import pytesseract
from PIL import Image

router = APIRouter()

# 确保data目录存在
DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)

class OCRResponse(BaseModel):
    text: str

@router.post("/upload/")
async def upload_file(file: UploadFile = File(...)):
    """
    上传文件并保存到data目录，返回文件ID
    """
    # 生成唯一ID
    file_id = str(uuid.uuid4())
    
    # 获取文件扩展名
    file_extension = os.path.splitext(file.filename)[1]
    
    # 创建文件路径
    file_path = os.path.join(DATA_DIR, f"{file_id}{file_extension}")
    
    # 保存文件
    with open(file_path, "wb") as buffer:
        content = await file.read()
        buffer.write(content)
    
    return {"id": file_id, "filename": file.filename}

@router.get("/ocr/{file_id}")
async def ocr_file(file_id: str):
    """
    根据文件ID进行OCR识别并返回文本
    """
    # 查找匹配的文件
    file_path = None
    for filename in os.listdir(DATA_DIR):
        if filename.startswith(file_id):
            file_path = os.path.join(DATA_DIR, filename)
            break
    
    if not file_path or not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    
    try:
        # 使用Pillow打开图片
        image = Image.open(file_path)
        
        # 使用pytesseract进行OCR识别
        text = pytesseract.image_to_string(image, lang='chi_sim+eng')
        
        return OCRResponse(text=text.strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"OCR processing failed: {str(e)}")