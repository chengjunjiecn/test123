from fastapi import FastAPI
from app.api import routes

app = FastAPI(title="OCR Service API")

app.include_router(routes.router)

@app.get("/")
async def root():
    return {"message": "Welcome to OCR Service API"}