import requests
import os

# 测试服务器地址
BASE_URL = "http://localhost:8000"

def test_file_upload():
    """
    测试文件上传功能
    """
    # 准备测试文件
    test_file_path = "test_image.png"
    
    # 如果测试文件不存在，则创建一个简单的测试文件
    if not os.path.exists(test_file_path):
        # 创建一个简单的文本文件作为测试
        with open(test_file_path, "w") as f:
            f.write("This is a test file for upload testing.")
    
    # 准备上传文件
    with open(test_file_path, "rb") as f:
        files = {"file": (test_file_path, f, "image/png")}
        response = requests.post(f"{BASE_URL}/upload/", files=files)
    
    # 检查响应
    if response.status_code == 200:
        result = response.json()
        print("文件上传成功!")
        print(f"文件ID: {result['id']}")
        print(f"文件名: {result['filename']}")
        return result['id']
    else:
        print(f"文件上传失败! 状态码: {response.status_code}")
        print(f"错误信息: {response.text}")
        return None

def test_ocr_service(file_id):
    """
    测试OCR服务
    """
    if not file_id:
        print("无效的文件ID")
        return
    
    response = requests.get(f"{BASE_URL}/ocr/{file_id}")
    
    if response.status_code == 200:
        result = response.json()
        print("OCR识别成功!")
        print(f"识别结果: {result['text']}")
    else:
        print(f"OCR识别失败! 状态码: {response.status_code}")
        print(f"错误信息: {response.text}")

if __name__ == "__main__":
    print("开始测试文件上传和OCR服务...")
    
    # 测试文件上传
    file_id = test_file_upload()
    
    # 如果上传成功，测试OCR服务
    if file_id:
        # 等待一段时间确保文件完全保存
        import time
        time.sleep(1)
        test_ocr_service(file_id)